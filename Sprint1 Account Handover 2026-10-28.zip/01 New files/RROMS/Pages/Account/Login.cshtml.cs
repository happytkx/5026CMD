using System.ComponentModel.DataAnnotations;
using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.RateLimiting;
using RROMS.Services;
namespace RROMS.Pages.Account;

[EnableRateLimiting("accounts")]
public class LoginModel(CustomerAccountService accounts) : PageModel
{
    [BindProperty] public Credentials Input { get; set; } = new();
    [BindProperty(SupportsGet = true)] public string? ReturnUrl { get; set; }
    public class Credentials
    {
        [Required, EmailAddress, StringLength(100)] public string Email { get; set; } = "";
        [Required, StringLength(128), DataType(DataType.Password)] public string Password { get; set; } = "";
    }
    public async Task<IActionResult> OnPostAsync()
    {
        if (!ModelState.IsValid) return Page();
        var customer = await accounts.Authenticate(Input.Email, Input.Password);
        if (customer == null)
        {
            ModelState.AddModelError("", "Unable to sign in. Check your details, verify your email, or try again later if you have made several unsuccessful attempts.");
            return Page();
        }
        var id = customer.CustomerID.ToString();
        var identity = new ClaimsIdentity(new[] { new Claim(ClaimTypes.NameIdentifier, id),
            new Claim("CustomerID", id), new Claim(ClaimTypes.Name, customer.CustomerName),
            new Claim(ClaimTypes.Email, customer.Email), new Claim(ClaimTypes.Role, "Customer"),
            new Claim("SessionVersion", customer.SessionVersion.ToString()) },
            CookieAuthenticationDefaults.AuthenticationScheme);
        await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(identity));
        return Url.IsLocalUrl(ReturnUrl) ? LocalRedirect(ReturnUrl!) : RedirectToPage("/Reservations/Index");
    }
}
