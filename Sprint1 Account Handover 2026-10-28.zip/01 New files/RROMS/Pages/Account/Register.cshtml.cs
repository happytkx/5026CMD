using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.RateLimiting;
using RROMS.Services;
namespace RROMS.Pages.Account;

[EnableRateLimiting("accounts")]
public class RegisterModel(CustomerAccountService accounts) : PageModel
{
    [BindProperty] public Registration Input { get; set; } = new();
    public class Registration
    {
        [Required, StringLength(100), Display(Name = "Full name")] public string Name { get; set; } = "";
        [Required, EmailAddress, StringLength(100)] public string Email { get; set; } = "";
        [Required, Phone, StringLength(20), Display(Name = "Phone number")] public string Phone { get; set; } = "";
        [Required, StringLength(128, MinimumLength = 10), DataType(DataType.Password)] public string Password { get; set; } = "";
        [Required, Compare(nameof(Password)), DataType(DataType.Password), Display(Name = "Confirm password")] public string ConfirmPassword { get; set; } = "";
    }
    public async Task<IActionResult> OnPostAsync()
    {
        if (!ModelState.IsValid) return Page();
        try
        {
            var customer = await accounts.Register(Input.Name, Input.Email, Input.Phone, Input.Password);
            var sent = await accounts.SendVerification(customer, HttpContext.RequestAborted);
            TempData["AccountMessage"] = sent ? "Your account has been created. Check your inbox and spam folder for the verification link."
                : "Your account has been created, but the verification email could not be sent. Please try resending below or contact the restaurant.";
            return RedirectToPage("VerifyEmail");
        }
        catch (InvalidOperationException ex) { ModelState.AddModelError("", ex.Message); return Page(); }
    }
}
