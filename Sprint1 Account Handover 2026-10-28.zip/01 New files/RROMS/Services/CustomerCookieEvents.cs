// Password recovery invalidates all older customer cookies on their next request.
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.EntityFrameworkCore;
using RROMS.Data;
namespace RROMS.Services;

public class CustomerCookieEvents(ApplicationDbContext db, IWebHostEnvironment environment, IConfiguration config) : CookieAuthenticationEvents
{
    public override async Task ValidatePrincipal(CookieValidatePrincipalContext context)
    {
        var user = context.Principal;
        if (user?.IsInRole("Customer") != true) return;
        if (environment.IsDevelopment() && config.GetValue<bool>("Sprint2:EnableDemoAccess") &&
            user.FindFirst("DevelopmentPreview")?.Value == "true") return;
        var id = ReservationIdentity.CustomerId(user);
        var account = await db.Customers.AsNoTracking().Where(c => c.CustomerID == id && c.EmailConfirmed && c.PasswordHash != null)
            .Select(c => new { c.SessionVersion }).SingleOrDefaultAsync();
        if (account == null || user.FindFirst("SessionVersion")?.Value != account.SessionVersion.ToString())
        {
            context.RejectPrincipal();
            await context.HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
        }
    }
}
