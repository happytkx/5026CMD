// Console verification runner: checks policy boundaries and, with --integration, creates an isolated temporary SQL database to verify migrations and workflows. SMTP uses a fake sender.
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using RROMS.Data;
using RROMS.Models;
using RROMS.Services;

int passed = 0;
void Check(bool condition, string name)
{
    if (!condition)
        throw new Exception("FAIL: " + name);
    Console.WriteLine("PASS: " + name);
    passed++;
}
async Task Reject(Func<Task> operation, string name)
{
    try
    {
        await operation();
    }
    catch (InvalidOperationException) { Check(true, name); return; }
    throw new Exception("FAIL: expected rejection: " + name);
}
var now = ReservationPolicy.Now;
Check(ReservationPolicy.Areas(1).SequenceEqual(new[] { "Indoor", "Outdoor" }), "1 guest area filter");
Check(ReservationPolicy.Areas(3).Length == 2 && ReservationPolicy.Areas(4).Length == 2 && ReservationPolicy.Areas(5).Length == 2 && ReservationPolicy.Areas(6).Length == 3 && ReservationPolicy.Areas(8).Length == 3, "3/4/5/6/8 guest boundaries");
Check(ReservationPolicy.Areas(9).SequenceEqual(new[] { "VIP Room" }) && ReservationPolicy.Areas(12).Length == 1, "9–12 VIP only");
Check(ReservationPolicy.Areas(0).Length == 0 && ReservationPolicy.Areas(13).Length == 0, "Invalid party sizes");
Check(ReservationPolicy.SuitableCapacity(1, "Indoor", 2) && ReservationPolicy.SuitableCapacity(2, "Outdoor", 4)
    && !ReservationPolicy.SuitableCapacity(1, "Indoor", 6), "Small parties restricted to 2–4 seats");
Check(ReservationPolicy.SuitableCapacity(3, "Indoor", 4) && ReservationPolicy.SuitableCapacity(4, "Indoor", 6)
    && !ReservationPolicy.SuitableCapacity(3, "Indoor", 8), "3–4 guests restricted to 4–6 seats");
Check(ReservationPolicy.SuitableCapacity(5, "Outdoor", 6) && ReservationPolicy.SuitableCapacity(6, "Indoor", 8)
    && !ReservationPolicy.SuitableCapacity(5, "Indoor", 10), "5–6 guests restricted to 6–8 seats");
Check(ReservationPolicy.SuitableCapacity(7, "Indoor", 8) && ReservationPolicy.SuitableCapacity(8, "Indoor", 8)
    && !ReservationPolicy.SuitableCapacity(7, "Indoor", 10) && !ReservationPolicy.SuitableCapacity(7, "Indoor", 6), "7–8 guests require 8 seats");
Check(ReservationPolicy.SuitableCapacity(6, "VIP Room", 12) && ReservationPolicy.SuitableCapacity(12, "VIP Room", 12)
    && !ReservationPolicy.SuitableCapacity(1, "VIP Room", 12), "VIP eligibility and actual room capacity preserved");
Check(ReservationPolicy.MinimumSpend(6, "VIP Room") == 2400 && ReservationPolicy.MinimumSpend(8, "VIP Room") == 2400 && ReservationPolicy.MinimumSpend(9, "VIP Room") == 3600, "VIP minimum spend tiers");
Check(ReservationPolicy.MinimumSpend(3, "Indoor") == 150, "Standard minimum spend");
var start = now.Date.AddDays(10).AddHours(18);
Check(ReservationPolicy.End(start, "Indoor", TimeSpan.FromHours(22)) == start.AddHours(2), "Standard duration 2 hours");
Check(ReservationPolicy.End(start, "VIP Room", TimeSpan.FromHours(22)) == start.Date.AddHours(22), "VIP ends at closing");
Check(!ReservationPolicy.Overlaps(start, start.AddHours(2), start.AddHours(2), start.AddHours(4)), "Adjacent bookings allowed");
Check(ReservationPolicy.Overlaps(start, start.AddHours(2), start.AddMinutes(119), start.AddHours(4)), "Partial overlap rejected");
Check(ReservationPolicy.CanModify(now.AddHours(168), 0, now) && !ReservationPolicy.CanModify(now.AddHours(168).AddTicks(-1), 0, now), "Exact 168-hour boundary");
Check(!ReservationPolicy.CanModify(now.AddDays(20), 1, now), "Second modification rejected");
Check(ReservationPolicy.IsExpired(now.AddMinutes(-10), false, now) && !ReservationPolicy.IsExpired(now.AddMinutes(-10), true, now), "Normal 10-minute expiry");
Check(ReservationPolicy.IsExpired(now.AddMinutes(-30), true, now), "Notified 30-minute expiry");
if (!args.Contains("--integration")) { Console.WriteLine($"{passed} policy checks passed. Use --integration for SQL Server workflow checks."); return; }

// This run owns a uniquely named database. Never use the application's real database.
var database = "RROMS_Sprint2_Test_" + Guid.NewGuid().ToString("N");
var connection = $"Server=(localdb)\\MSSQLLocalDB;Database={database};Trusted_Connection=True;TrustServerCertificate=True";
var options = new DbContextOptionsBuilder<ApplicationDbContext>().UseSqlServer(connection).Options;
await using var db = new ApplicationDbContext(options);
try
{
    var migrator = db.GetService<Microsoft.EntityFrameworkCore.Migrations.IMigrator>();
    await migrator.MigrateAsync("20261011054116_InitialCreate");
    await db.Database.ExecuteSqlRawAsync("INSERT INTO RestaurantSettings (DepositPerPerson,ReservationDurationMinutes,MaxModificationCount,GracePeriod,LateArrivalPeriod) VALUES (50,150,1,10,30)");
    DbInitializer.Initialize(db);
    var unusedColumns = await db.Database.SqlQueryRaw<int>("SELECT COUNT(*) AS [Value] FROM sys.columns c JOIN sys.tables t ON c.object_id=t.object_id WHERE (t.name='Customers' AND c.name='Password') OR (t.name='DiningAreas' AND c.name IN ('AreaName','Description')) OR (t.name='RestaurantSettings' AND c.name IN ('DepositPerPerson','ReservationDurationMinutes','MaxModificationCount','GracePeriod','LateArrivalPeriod'))").SingleAsync();
    Check(unusedColumns == 0, "Unused columns removed by schema upgrade");
    var migratedSettings = await db.RestaurantSettings.FirstAsync();
    Check(migratedSettings.OpeningTime == TimeSpan.FromHours(12) && migratedSettings.ClosingTime == TimeSpan.FromHours(22), "Existing settings upgraded with usable opening hours");
    var service = new ReservationService(db, new TableAllocationService(db));
    var allocation = new TableAllocationService(db);
    var customer = await db.Customers.FirstAsync();
    var other = new Customer { CustomerName = "Other Customer", Email = "other@example.test", PhoneNo = "000" };
    db.Customers.Add(other);
    await db.SaveChangesAsync();
    var booking = await service.Create(customer.CustomerID, 2, "Indoor", start, "No peanuts");
    Check(booking.ReservationStatus == "Pending" && booking.DepositAmount == 100 && booking.TableID == "T01", "Create pending; smallest suitable table; deposit calculated");
    Check(booking.EndTime == TimeSpan.FromHours(20), "Persisted 2-hour booking");
    await Reject(() => service.Change(booking.ReservationID, other.CustomerID, false, "Cancel"), "Other customer cannot manage booking");
    await service.Change(booking.ReservationID, customer.CustomerID, false, "Pay", paymentSuccess: false);
    Check(booking.ReservationStatus == "Pending" && await db.Payments.CountAsync() == 1, "Failed payment records attempt; remains pending");
    Check(await db.ReservationEmails.CountAsync() == 0, "Failed deposit does not queue confirmation email");
    await service.Change(booking.ReservationID, customer.CustomerID, false, "Pay");
    Check(booking.ReservationStatus == "Confirmed" && booking.DepositStatus == "Paid", "Successful simulated deposit confirms booking");
    Check(await db.ReservationEmails.CountAsync() == 1, "Successful deposit atomically queues one confirmation email");
    Check(await db.Payments.AnyAsync(p => p.ReservationID == booking.ReservationID && p.PaymentStatus == "Paid" && p.PaymentMethod == "Card" && p.PaymentReference.StartsWith("SIM-")), "Deposit receipt stores configured method and reference");
    await Reject(() => service.Change(booking.ReservationID, customer.CustomerID, false, "Pay"), "Duplicate successful payment rejected");
    Check(await db.Payments.CountAsync() == 2, "Duplicate payment adds no record");
    await Reject(() => service.Change(booking.ReservationID, customer.CustomerID, false, "CheckIn"), "Customer cannot check in themselves");
    Check(!(await allocation.Available(2, "Indoor", start, start.AddHours(2))).Any(t => t.TableID == booking.TableID), "Booked table excluded from overlapping availability");
    Check((await allocation.Available(2, "Indoor", start.AddHours(2), start.AddHours(4))).Any(t => t.TableID == booking.TableID), "Table available for adjacent reservation");
    await service.Change(booking.ReservationID, customer.CustomerID, false, "Modify", start.AddDays(1));
    Check(booking.ModificationCount == 1 && booking.OriginalStart == start && booking.DepositAmount == 100 && booking.DepositStatus == "Paid" && await db.ReservationHistories.CountAsync() == 1, "Modify preserves original deadline and deposit; creates history");
    await Reject(() => service.Change(booking.ReservationID, null, true, "Modify", start.AddDays(2)), "Staff cannot override one-modification limit");
    await service.Change(booking.ReservationID, customer.CustomerID, false, "Cancel");
    Check(booking.ReservationStatus == "Cancelled" && booking.DepositStatus == "Forfeited", "Cancellation forfeits deposit");
    await Reject(() => service.Create(customer.CustomerID, 3, "VIP Room", start, null), "VIP denied for 1–3 guests");
    await Reject(() => service.Create(customer.CustomerID, 4, "VIP Room", start, null), "VIP denied for 4 guests");
    await Reject(() => service.Create(customer.CustomerID, 5, "VIP Room", start, null), "VIP denied for 5 guests");
    await Reject(() => service.Create(customer.CustomerID, 9, "Outdoor", start, null), "Non-VIP denied for 9–12 guests");
    await Reject(() => service.Create(customer.CustomerID, 2, "Indoor", start.Date.AddHours(21), null), "Standard booking cannot cross closing");
    var vip = await service.Create(customer.CustomerID, 9, "VIP Room", start, null);
    Check(vip.MinimumSpend == 3600 && vip.EndTime == TimeSpan.FromHours(22) && vip.TableID == "VIP02", "Large VIP reservation minimum and closing time");
    await Reject(() => service.Create(customer.CustomerID, 9, "VIP Room", start.AddHours(1), null), "VIP blocked through closing");
    await service.Change(vip.ReservationID, customer.CustomerID, false, "Pay");
    await Reject(() => service.Change(vip.ReservationID, null, true, "Reassign", tableId: "T03"), "Staff reassignment cannot cross area/capacity");
    await service.Change(vip.ReservationID, customer.CustomerID, false, "Late");
    Check(vip.LateArrivalNotified, "Late notification persisted");
    await service.Change(vip.ReservationID, customer.CustomerID, false, "Cancel");
    var expired = await service.Create(customer.CustomerID, 6, "VIP Room", start, null);
    expired.HoldExpiresAt = ReservationPolicy.Now.AddMinutes(-1);
    await db.SaveChangesAsync();
    await service.Expire();
    Check(expired.ReservationStatus == "Expired" && expired.DepositStatus == "Unpaid", "Unpaid hold expiry releases room without forfeiting unpaid deposit");
    var arrival = await service.Create(customer.CustomerID, 2, "Indoor", start, null);
    await service.Change(arrival.ReservationID, customer.CustomerID, false, "Pay");
    arrival.ReservationDate = ReservationPolicy.Now.Date;
    arrival.StartTime = ReservationPolicy.Now.TimeOfDay.Subtract(TimeSpan.FromMinutes(5));
    arrival.EndTime = arrival.StartTime.Add(TimeSpan.FromHours(2));
    await db.SaveChangesAsync();
    await service.Change(arrival.ReservationID, null, true, "CheckIn");
    Check(arrival.ReservationStatus == "Seated" && arrival.OrderingEnabled && arrival.CheckedInAt != null, "Staff check-in activates ordering");
    await service.Change(arrival.ReservationID, null, true, "Complete");
    Check(arrival.ReservationStatus == "Completed" && !arrival.OrderingEnabled, "Completion closes ordering");
    var noShow = await service.Create(customer.CustomerID, 2, "Indoor", start, null);
    await service.Change(noShow.ReservationID, customer.CustomerID, false, "Pay");
    noShow.ReservationDate = ReservationPolicy.Now.Date;
    noShow.StartTime = ReservationPolicy.Now.TimeOfDay.Subtract(TimeSpan.FromMinutes(11));
    await db.SaveChangesAsync();
    await service.Expire();
    Check(noShow.ReservationStatus == "No-show" && noShow.DepositStatus == "Forfeited", "Automatic normal no-show forfeits deposit");
    var notified = await service.Create(customer.CustomerID, 2, "Indoor", start.AddDays(3), null);
    await service.Change(notified.ReservationID, customer.CustomerID, false, "Pay");
    await service.Change(notified.ReservationID, customer.CustomerID, false, "Late");
    notified.ReservationDate = ReservationPolicy.Now.Date;
    notified.StartTime = ReservationPolicy.Now.TimeOfDay.Subtract(TimeSpan.FromMinutes(11));
    await db.SaveChangesAsync();
    await service.Expire();
    Check(notified.ReservationStatus == "Confirmed", "Notified booking survives 10-minute deadline");
    notified.StartTime = ReservationPolicy.Now.TimeOfDay.Subtract(TimeSpan.FromMinutes(31));
    await db.SaveChangesAsync();
    await service.Expire();
    Check(notified.ReservationStatus == "No-show", "Notified booking expires after 30 minutes");
    async Task<bool> ConcurrentBooking()
    {
        await using var concurrentDb = new ApplicationDbContext(options);
        var concurrentService = new ReservationService(concurrentDb, new TableAllocationService(concurrentDb));
        try
        {
            await concurrentService.Create(customer.CustomerID, 12, "VIP Room", start.AddDays(40), null);
            return true;
        }
        catch (InvalidOperationException) { return false; }
        catch (DbUpdateException) { return false; }
        catch (Microsoft.Data.SqlClient.SqlException ex) when (ex.Number == 1205) { return false; }
    }
    var race = await Task.WhenAll(ConcurrentBooking(), ConcurrentBooking());
    Check(race.Count(success => success) == 1 && await db.Reservations.CountAsync(r => r.ReservationDate == start.AddDays(40).Date && r.TableID == "VIP02") == 1,
        "Simultaneous requests cannot double-book a VIP room");
    var emailBooking = await service.Create(customer.CustomerID, 6, "VIP Room", start.AddDays(60), null);
    await service.Change(emailBooking.ReservationID, customer.CustomerID, false, "Pay");
    var fakeSender = new FakeEmailSender();
    var emailOptions = Microsoft.Extensions.Options.Options.Create(new EmailOptions { Enabled = true, ReminderHours = [24] });
    var emailService = new ReservationEmailService(db, fakeSender, emailOptions, Microsoft.Extensions.Logging.Abstractions.NullLogger<ReservationEmailService>.Instance);
    await emailService.QueueReminders(ReservationPolicy.Now);
    await emailService.QueueReminders(ReservationPolicy.Now);
    var reminderKey = $"reminder:{emailBooking.ReservationID}:0:24";
    Check(await db.ReservationEmails.CountAsync(e => e.EventKey == reminderKey) == 1, "Reminder scheduling is idempotent");
    await emailService.Dispatch(ReservationPolicy.Now);
    Check(fakeSender.Bodies.Any(body => body.Contains(emailBooking.BookingReference) && body.Contains("RM2,400.00") && body.Contains("UTC+8")), "Confirmation email contains booking, VIP policy and Malaysia time");
    Check(!fakeSender.Bodies.Any(body => body.Contains(booking.BookingReference)), "Cancelled booking emails are suppressed");
    var sentBefore = fakeSender.Bodies.Count;
    await emailService.Dispatch(ReservationPolicy.Now);
    Check(fakeSender.Bodies.Count == sentBefore, "Sent confirmations are not resent on next poll");
    var dueAt = emailBooking.ReservationDate.Add(emailBooking.StartTime).AddHours(-24);
    await emailService.Dispatch(dueAt.AddSeconds(-1));
    Check(!fakeSender.Bodies.Any(body => body.Contains("look forward") && body.Contains(emailBooking.BookingReference)), "Arrival reminder is not sent before its due time");
    fakeSender.FailNext = true;
    await emailService.Dispatch(dueAt);
    var retryMail = await db.ReservationEmails.AsNoTracking().SingleAsync(e => e.EventKey == reminderKey);
    Check(retryMail.Status == "Queued" && retryMail.Attempts == 1 && retryMail.DueAt > dueAt, "SMTP failure records retry without changing booking");
    await emailService.Dispatch(retryMail.DueAt);
    Check(await db.ReservationEmails.AsNoTracking().AnyAsync(e => e.EventKey == reminderKey && e.Status == "Sent"), "Arrival reminder is delivered after retry");
    await service.Change(emailBooking.ReservationID, customer.CustomerID, false, "Modify", start.AddDays(61));
    await emailService.QueueReminders(ReservationPolicy.Now);
    Check(await db.ReservationEmails.AnyAsync(e => e.EventKey == $"reminder:{emailBooking.ReservationID}:1:24" && e.BookingStart == start.AddDays(61)), "Rescheduling creates a reminder for the updated booking");
    var stopped = new ReservationEmailService(db, fakeSender, Microsoft.Extensions.Options.Options.Create(new EmailOptions { Enabled = false }), Microsoft.Extensions.Logging.Abstractions.NullLogger<ReservationEmailService>.Instance);
    sentBefore = fakeSender.Bodies.Count;
    await stopped.Dispatch(ReservationPolicy.Now);
    Check(fakeSender.Bodies.Count == sentBefore, "Disabled SMTP never sends messages");
    // Capacity limits and explicit staff exceptions use a separate future date.
    var capacityStart = start.AddDays(80);
    Check((await allocation.Available(1, "Indoor", capacityStart, capacityStart.AddHours(2)))
        .Select(t => t.Capacity).SequenceEqual(new[] { 2, 4 }), "Small party availability includes only suitable tables in smallest-first order");
    Check((await service.Slots(1, "Outdoor", capacityStart.Date)).Count == 0,
        "No arrival slots when only oversized tables exist in selected area");
    await Reject(() => service.Create(customer.CustomerID, 1, "Outdoor", capacityStart, null),
        "Customer cannot automatically book an oversized table");
    var smallBooking = await service.Create(customer.CustomerID, 1, "Indoor", capacityStart, null);
    await service.Change(smallBooking.ReservationID, customer.CustomerID, false, "Pay");
    var indoorArea = await db.DiningAreas.SingleAsync(a => a.AreaType == "Indoor");
    db.RestaurantTables.Add(new RROMS.Models.RestaurantTable { TableID = "TEST-LARGE", DiningAreaID = indoorArea.DiningAreaID, Capacity = 8, Status = "Available" });
    await db.SaveChangesAsync();
    await Reject(() => service.Change(smallBooking.ReservationID, null, true, "Reassign", tableId: "TEST-LARGE"),
        "Staff cannot silently reassign to oversized table");
    await Reject(() => service.Change(smallBooking.ReservationID, customer.CustomerID, false, "Reassign", tableId: "TEST-LARGE", allowLargerTable: true, reassignmentReason: "Exception"),
        "Customer cannot request staff capacity exception");
    await Reject(() => service.Change(smallBooking.ReservationID, null, true, "Reassign", tableId: "TEST-LARGE", allowLargerTable: true),
        "Larger table exception requires reason");
    await service.Change(smallBooking.ReservationID, null, true, "Reassign", tableId: "TEST-LARGE", allowLargerTable: true, reassignmentReason: "Accessible seating requested");
    Check(smallBooking.TableID == "TEST-LARGE" && await db.Notifications.AnyAsync(n => n.ReservationID == smallBooking.ReservationID && n.Message.Contains("Accessible seating requested")),
        "Staff exception succeeds and records reason");
    Check(!(await allocation.Available(1, "Indoor", capacityStart, capacityStart.AddHours(2), allowLargerTable: true)).Any(t => t.TableID == "TEST-LARGE"),
        "Capacity exception still excludes conflicting tables");
    var accountSender = new FakeEmailSender();
    var accountConfig = new Microsoft.Extensions.Configuration.ConfigurationBuilder().AddInMemoryCollection(
        new Dictionary<string, string?> { ["Accounts:PublicBaseUrl"] = "https://localhost:7096" }).Build();
    var accounts = new CustomerAccountService(db, new Microsoft.AspNetCore.Identity.PasswordHasher<Customer>(), accountSender,
        accountConfig, Microsoft.Extensions.Logging.Abstractions.NullLogger<CustomerAccountService>.Instance);
    const string accountPassword = "A-test-passphrase-2026";
    var registered = await accounts.Register("Registered Customer", "New.Account@example.test", "0123456789", accountPassword);
    Check(registered.CustomerID > 0 && registered.PasswordHash != accountPassword && registered.NormalizedEmail == "NEW.ACCOUNT@EXAMPLE.TEST",
        "Registration creates reservation-compatible customer with hashed password and normalized email");
    await Reject(() => accounts.Register("Duplicate", "new.account@EXAMPLE.test", "000", accountPassword), "Case-insensitive duplicate registration rejected");
    await Reject(() => accounts.Register("Legacy takeover", customer.Email, "000", accountPassword), "Signup cannot take over existing reservation customer");
    Check(await accounts.Authenticate(registered.Email, accountPassword) == null, "Unverified account cannot log in");
    Check(await accounts.SendVerification(registered, CancellationToken.None), "Verification email sent through fake transport");
    var confirmationUrl = new Uri(accountSender.Bodies.Last().Split('\n').Single(line => line.StartsWith("https://")));
    var confirmationQuery = Microsoft.AspNetCore.WebUtilities.QueryHelpers.ParseQuery(confirmationUrl.Query);
    var accountToken = confirmationQuery["token"].ToString();
    Check(registered.VerificationTokenHash != accountToken && accountToken.Length == 64 && confirmationUrl.Host == "localhost",
        "Verification stores token hash and uses configured origin");
    Check(!await accounts.SendVerification(registered, CancellationToken.None), "Verification resend has cooldown");
    Check(!await accounts.Confirm(registered.CustomerID, "invalid"), "Malformed verification token rejected");
    registered.VerificationExpiresUtc = DateTime.UtcNow.AddMinutes(-1); await db.SaveChangesAsync();
    Check(!await accounts.Confirm(registered.CustomerID, accountToken), "Expired verification link rejected");
    registered.VerificationSentUtc = DateTime.UtcNow.AddMinutes(-2);
    await db.SaveChangesAsync(); await accounts.SendVerification(registered, CancellationToken.None);
    confirmationUrl = new Uri(accountSender.Bodies.Last().Split('\n').Single(line => line.StartsWith("https://")));
    var replacementToken = Microsoft.AspNetCore.WebUtilities.QueryHelpers.ParseQuery(confirmationUrl.Query)["token"].ToString();
    Check(!await accounts.Confirm(registered.CustomerID, accountToken), "Resending invalidates previous verification token");
    Check(await accounts.Confirm(registered.CustomerID, replacementToken), "Valid verification confirms customer email");
    Check(!await accounts.Confirm(registered.CustomerID, replacementToken), "Verification link is single-use");
    db.ChangeTracker.Clear();
    Check(await accounts.Authenticate("new.account@EXAMPLE.test", accountPassword) != null, "Confirmed account signs in case-insensitively");
    for (var attempt = 0; attempt < 5; attempt++) await accounts.Authenticate(registered.Email, "IncorrectPassword");
    Check(await accounts.Authenticate(registered.Email, accountPassword) == null, "Repeated failed passwords lock the account temporarily");
    var lockedCustomer = await db.Customers.SingleAsync(c => c.CustomerID == registered.CustomerID);
    lockedCustomer.LockedUntilUtc = DateTime.UtcNow.AddMinutes(-1); await db.SaveChangesAsync();
    Check(await accounts.Authenticate(registered.Email, accountPassword) != null, "Correct password works after lockout expires");
    var registeredBooking = await service.Create(registered.CustomerID, 2, "Indoor", start.AddDays(90), "Account integration test");
    Check(registeredBooking.CustomerID == registered.CustomerID, "New account can own a reservation without changing existing records");
    var resetAccount = await accounts.Register("Reset Customer", "reset-check@example.test", "0123456789", accountPassword);
    resetAccount.EmailConfirmed = true; await db.SaveChangesAsync();
    Check(!await accounts.SendPasswordReset("unknown@example.test", CancellationToken.None)
        && !await accounts.SendPasswordReset(customer.Email, CancellationToken.None), "Reset does not claim unknown or legacy accounts");
    Check(await accounts.SendPasswordReset(resetAccount.Email, CancellationToken.None), "Verified account receives password reset link through fake sender");
    string LastResetToken() => Microsoft.AspNetCore.WebUtilities.QueryHelpers.ParseQuery(new Uri(accountSender.Bodies.Last()
        .Split('\n').Single(line => line.StartsWith("https://"))).Query)["token"].ToString();
    var oldResetToken = LastResetToken();
    Check(resetAccount.PasswordResetTokenHash != oldResetToken && oldResetToken.Length == 64, "Password reset stores only a cryptographic token hash");
    Check(!await accounts.SendPasswordReset(resetAccount.Email, CancellationToken.None), "Password reset requests have resend cooldown");
    Check(!await accounts.CanResetPassword(resetAccount.CustomerID, "bad-token")
        && !await accounts.CanResetPassword(registered.CustomerID, oldResetToken), "Invalid and cross-account reset tokens rejected");
    resetAccount.PasswordResetExpiresUtc = DateTime.UtcNow.AddMinutes(-1); await db.SaveChangesAsync();
    Check(!await accounts.ResetPassword(resetAccount.CustomerID, oldResetToken, "New-test-passphrase-2026"), "Expired reset token cannot change password");
    resetAccount.PasswordResetSentUtc = DateTime.UtcNow.AddMinutes(-2); await db.SaveChangesAsync();
    await accounts.SendPasswordReset(resetAccount.Email, CancellationToken.None);
    var newResetToken = LastResetToken();
    Check(!await accounts.CanResetPassword(resetAccount.CustomerID, oldResetToken), "New reset request invalidates previous reset link");
    Check(!await accounts.ResetPassword(resetAccount.CustomerID, newResetToken, "short"), "Reset enforces password length on server");
    Check(await accounts.ResetPassword(resetAccount.CustomerID, newResetToken, "New-test-passphrase-2026"), "Valid reset replaces password");
    Check(!await accounts.ResetPassword(resetAccount.CustomerID, newResetToken, accountPassword), "Password reset link cannot be reused");
    db.ChangeTracker.Clear();
    Check(await accounts.Authenticate(resetAccount.Email, accountPassword) == null
        && await accounts.Authenticate(resetAccount.Email, "New-test-passphrase-2026") != null, "Only new password signs in after reset");
    Check(await db.Customers.AnyAsync(c => c.CustomerID == resetAccount.CustomerID && c.SessionVersion == 1 && c.PasswordResetTokenHash == null),
        "Reset consumes token and increments cookie session version");
    // Exercise the actual Razor endpoints and cookie/antiforgery integration against this test database.
    var listener = new System.Net.Sockets.TcpListener(System.Net.IPAddress.Loopback, 0);
    listener.Start(); var webPort = ((System.Net.IPEndPoint)listener.LocalEndpoint).Port; listener.Stop();
    var startInfo = new System.Diagnostics.ProcessStartInfo("dotnet") { UseShellExecute = false };
    foreach (var argument in new[] { typeof(ReservationService).Assembly.Location, "--contentRoot", Path.GetFullPath("RROMS"),
        "--urls", $"https://localhost:{webPort}", "--ConnectionStrings:DefaultConnection", connection,
        "--Email:Enabled", "false", "--Logging:LogLevel:Default", "Critical" }) startInfo.ArgumentList.Add(argument);
    startInfo.Environment["ASPNETCORE_ENVIRONMENT"] = "Development";
    using var webServer = System.Diagnostics.Process.Start(startInfo)!;
    try
    {
        using var http = new HttpClient(new HttpClientHandler { AllowAutoRedirect = false, CookieContainer = new System.Net.CookieContainer() })
            { BaseAddress = new Uri($"https://localhost:{webPort}"), Timeout = TimeSpan.FromSeconds(10) };
        HttpResponseMessage? loginResponse = null;
        for (var retry = 0; retry < 40; retry++)
        {
            try { loginResponse = await http.GetAsync("/Account/Login"); break; }
            catch (HttpRequestException) { if (webServer.HasExited) throw; await Task.Delay(250); }
        }
        Check(loginResponse?.StatusCode == System.Net.HttpStatusCode.OK, "Login Razor page starts over HTTPS");
        var loginHtml = await loginResponse!.Content.ReadAsStringAsync();
        string Antiforgery(string html) => System.Net.WebUtility.HtmlDecode(System.Text.RegularExpressions.Regex.Match(html,
            "name=\"__RequestVerificationToken\"[^>]*value=\"([^\"]+)\"").Groups[1].Value);
        var registerPage = await http.GetAsync("/Account/Register");
        var registerHtml = await registerPage.Content.ReadAsStringAsync();
        Check(registerPage.IsSuccessStatusCode && registerHtml.Contains("Create your account"), "Registration page renders fields and restaurant styling");
        var invalidSignup = await http.PostAsync("/Account/Register", new FormUrlEncodedContent(new Dictionary<string, string> {
            ["Input.Name"] = "Web Customer", ["Input.Email"] = "http-account@example.test", ["Input.Phone"] = "0123456789",
            ["Input.Password"] = accountPassword, ["Input.ConfirmPassword"] = "Different password",
            ["__RequestVerificationToken"] = Antiforgery(registerHtml) }));
        Check(invalidSignup.IsSuccessStatusCode && !await db.Customers.AnyAsync(c => c.Email == "http-account@example.test"),
            "Registration rejects mismatched passwords without creating account");
        registerHtml = await (await http.GetAsync("/Account/Register")).Content.ReadAsStringAsync();
        var signup = await http.PostAsync("/Account/Register", new FormUrlEncodedContent(new Dictionary<string, string> {
            ["Input.Name"] = "Web Customer", ["Input.Email"] = "http-account@example.test", ["Input.Phone"] = "0123456789",
            ["Input.Password"] = accountPassword, ["Input.ConfirmPassword"] = accountPassword,
            ["__RequestVerificationToken"] = Antiforgery(registerHtml) }));
        Check(signup.StatusCode == System.Net.HttpStatusCode.Redirect && signup.Headers.Location!.ToString().Contains("VerifyEmail")
            && await db.Customers.AnyAsync(c => c.Email == "http-account@example.test" && !c.EmailConfirmed),
            "Signup saves unverified account and provides recovery when SMTP is disabled");
        Check((await http.GetAsync("/css/reservations.css")).IsSuccessStatusCode && (await http.GetAsync("/images/celeste-indoor.jpg")).IsSuccessStatusCode,
            "Account stylesheet and restaurant photograph load");
        var protectedPage = await http.GetAsync("/Reservations/Index");
        Check(protectedPage.StatusCode == System.Net.HttpStatusCode.Redirect && protectedPage.Headers.Location!.ToString().Contains("/Account/Login"),
            "Unauthenticated reservations redirect to real login");
        Check((await http.PostAsync("/Account/Login", new FormUrlEncodedContent(new Dictionary<string, string> {
            ["Input.Email"] = registered.Email, ["Input.Password"] = accountPassword }))).StatusCode == System.Net.HttpStatusCode.BadRequest,
            "Login submission without antiforgery token rejected");
        var loginPost = await http.PostAsync("/Account/Login", new FormUrlEncodedContent(new Dictionary<string, string> {
            ["Input.Email"] = registered.Email, ["Input.Password"] = accountPassword,
            ["ReturnUrl"] = "https://example.test/untrusted", ["__RequestVerificationToken"] = Antiforgery(loginHtml) }));
        Check(loginPost.StatusCode == System.Net.HttpStatusCode.Redirect && loginPost.Headers.Location!.ToString() == "/Reservations",
            "Login issues customer cookie and rejects external return URL");
        var ownList = await http.GetAsync("/Reservations/Index");
        var ownHtml = await ownList.Content.ReadAsStringAsync();
        Check(ownList.IsSuccessStatusCode && ownHtml.Contains(registeredBooking.BookingReference), "Authenticated customer sees own reservation");
        Check((await http.GetAsync($"/Reservations/Details/{booking.ReservationID}")).StatusCode == System.Net.HttpStatusCode.NotFound,
            "Customer cookie cannot access another customer's booking");
        var staffPage = await http.GetAsync("/Staff");
        Check(staffPage.StatusCode == System.Net.HttpStatusCode.Redirect && staffPage.Headers.Location!.ToString().Contains("/Account/Denied"),
            "Public registration cannot grant staff access");
        var forgotPage = await http.GetAsync("/Account/ForgotPassword");
        var forgotHtml = await forgotPage.Content.ReadAsStringAsync();
        Check(forgotPage.IsSuccessStatusCode && loginHtml.Contains("Forgot password?"), "Forgot-password page and login link are available");
        var unknownReset = await http.PostAsync("/Account/ForgotPassword", new FormUrlEncodedContent(new Dictionary<string, string> {
            ["Email"] = "nobody@example.test", ["__RequestVerificationToken"] = Antiforgery(forgotHtml) }));
        var knownReset = await http.PostAsync("/Account/ForgotPassword", new FormUrlEncodedContent(new Dictionary<string, string> {
            ["Email"] = registered.Email, ["__RequestVerificationToken"] = Antiforgery(forgotHtml) }));
        Check(unknownReset.IsSuccessStatusCode && knownReset.IsSuccessStatusCode
            && (await unknownReset.Content.ReadAsStringAsync()).Contains("If this email belongs to a verified account")
            && (await knownReset.Content.ReadAsStringAsync()).Contains("If this email belongs to a verified account"),
            "Forgot-password response does not disclose whether an email is registered");
        db.ChangeTracker.Clear();
        await accounts.SendPasswordReset(registered.Email, CancellationToken.None);
        var webResetToken = LastResetToken();
        var resetPage = await http.GetAsync($"/Account/ResetPassword?id={registered.CustomerID}&token={webResetToken}");
        var resetHtml = await resetPage.Content.ReadAsStringAsync();
        Check(resetPage.IsSuccessStatusCode && resetHtml.Contains("Choose a new password")
            && resetPage.Headers.CacheControl!.NoStore, "Valid reset page renders without caching");
        var badReset = await http.PostAsync("/Account/ResetPassword", new FormUrlEncodedContent(new Dictionary<string, string> {
            ["Id"] = registered.CustomerID.ToString(), ["Token"] = webResetToken,
            ["Password"] = "Reset-through-form-2026", ["ConfirmPassword"] = "Mismatch-password",
            ["__RequestVerificationToken"] = Antiforgery(resetHtml) }));
        Check(badReset.IsSuccessStatusCode && await accounts.CanResetPassword(registered.CustomerID, webResetToken),
            "Mismatched reset passwords do not consume valid link");
        var validReset = await http.PostAsync("/Account/ResetPassword", new FormUrlEncodedContent(new Dictionary<string, string> {
            ["Id"] = registered.CustomerID.ToString(), ["Token"] = webResetToken,
            ["Password"] = "Reset-through-form-2026", ["ConfirmPassword"] = "Reset-through-form-2026",
            ["__RequestVerificationToken"] = Antiforgery(resetHtml) }));
        Check(validReset.StatusCode == System.Net.HttpStatusCode.Redirect && validReset.Headers.Location!.ToString().Contains("Login"),
            "Successful password reset redirects to sign in");
        Check((await http.GetAsync("/Reservations/Index")).StatusCode == System.Net.HttpStatusCode.Redirect,
            "Password reset invalidates existing signed-in customer cookie");
        loginHtml = await (await http.GetAsync("/Account/Login")).Content.ReadAsStringAsync();
        var newPasswordLogin = await http.PostAsync("/Account/Login", new FormUrlEncodedContent(new Dictionary<string, string> {
            ["Input.Email"] = registered.Email, ["Input.Password"] = "Reset-through-form-2026",
            ["__RequestVerificationToken"] = Antiforgery(loginHtml) }));
        Check(newPasswordLogin.StatusCode == System.Net.HttpStatusCode.Redirect, "Customer can sign in with reset password through login page");
        ownHtml = await (await http.GetAsync("/Reservations/Index")).Content.ReadAsStringAsync();
        var logout = await http.PostAsync("/Access?handler=Logout", new FormUrlEncodedContent(new Dictionary<string, string> {
            ["__RequestVerificationToken"] = Antiforgery(ownHtml) }));
        Check(logout.StatusCode == System.Net.HttpStatusCode.Redirect && (await http.GetAsync("/Reservations/Index")).StatusCode == System.Net.HttpStatusCode.Redirect,
            "Logout clears the customer authentication cookie");
    }
    finally { if (!webServer.HasExited) { webServer.Kill(entireProcessTree: true); await webServer.WaitForExitAsync(); } }
    Console.WriteLine($"All {passed} checks passed against SQL Server.");
}

finally
{
    if (!database.StartsWith("RROMS_Sprint2_Test_"))
        throw new Exception("Invalid test cleanup target.");
    await db.Database.EnsureDeletedAsync();
}

class FakeEmailSender : IEmailSender
{
    public List<string> Bodies { get; } = [];
    public bool FailNext
    {
        get; set;
    }
    public Task SendAsync(string recipient, string subject, string body, string messageId, CancellationToken cancellationToken)
    {
        if (FailNext)
        {
            FailNext = false;
            throw new IOException("Simulated SMTP outage");
        }
        Bodies.Add(body);
        return Task.CompletedTask;
    }
}

