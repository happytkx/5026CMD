// Customer identity and contact details shared by customer login and reservations; passwords are stored only as hashes.
using System.ComponentModel.DataAnnotations;

namespace RROMS.Models
{
    public class Customer
    {
        [Key]
        public int CustomerID
        {
            get; set;
        }

        [Required]
        [StringLength(100)]
        public string CustomerName { get; set; } = string.Empty;

        [Required]
        [EmailAddress]
        [StringLength(100)]
        public string Email { get; set; } = string.Empty;

        [StringLength(20)]
        public string PhoneNo { get; set; } = string.Empty;

        // Nullable credentials preserve existing reservation-only customer records during upgrade.
        [StringLength(100)] public string? NormalizedEmail { get; set; }
        public string? PasswordHash { get; set; }
        public bool EmailConfirmed { get; set; }
        [StringLength(64)] public string? VerificationTokenHash { get; set; }
        public DateTime? VerificationExpiresUtc { get; set; }
        public DateTime? VerificationSentUtc { get; set; }
        public int FailedLoginCount { get; set; }
        public DateTime? LockedUntilUtc { get; set; }
        [StringLength(64)] public string? PasswordResetTokenHash { get; set; }
        public DateTime? PasswordResetExpiresUtc { get; set; }
        public DateTime? PasswordResetSentUtc { get; set; }
        public int SessionVersion { get; set; }

        public ICollection<Reservation> Reservations { get; set; } = [];
    }
}
